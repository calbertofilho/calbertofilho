package br.studio.calbertofilho.game;

import javax.swing.ImageIcon;

import br.studio.calbertofilho.game.controllers.containers.Window;

public class Launcher {

	public static void main(String[] args) {
		new Window("New Game Name", new ImageIcon("resources/assets/images/icon/gameIcon.png").getImage(), 1280, 720);
	}

}
