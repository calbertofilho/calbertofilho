package br.studio.calbertofilho.game.maps.tiles;

public enum ID {

	Path(),
	Hole(),
	Solid(),
	Interactive(),
	Decoration();

}
