package br.studio.calbertofilho.game.maps.tiles;

public enum TileID {

	Path(),
	Hole(),
	Solid(),
	Interactive(),
	Decoration();

}
