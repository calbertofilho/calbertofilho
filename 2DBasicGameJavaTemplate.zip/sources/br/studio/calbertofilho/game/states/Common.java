package br.studio.calbertofilho.game.states;

import java.awt.Graphics2D;

import br.studio.calbertofilho.game.controllers.handlers.Keyboard;
import br.studio.calbertofilho.game.controllers.handlers.Mouse;
import br.studio.calbertofilho.game.controllers.managers.GameStates;

public abstract class Common {

	protected GameStates manager;

	protected Common(GameStates manager) {
		this.manager = manager;
		init();
	}

	protected abstract void init();
	public abstract void input(Mouse mouse, Keyboard keyboard);
	public abstract void update();
	public abstract void render(Graphics2D graphics);

}
