package br.studio.calbertofilho.game.entities;

import java.awt.Graphics2D;

import br.studio.calbertofilho.game.controllers.handlers.Keyboard;
import br.studio.calbertofilho.game.controllers.handlers.Mouse;

public abstract class Character {

	protected float x, y;
	protected int width, height;
	protected float velX, velY;
	protected ID id;

	public Character(float x, float y, ID id) {
		this.x = x;
		this.y = y;
		this.id = id;
	}

	public Character() {}

	public abstract void input(Mouse mouse, Keyboard keyboard);
	public abstract void update();
	public abstract void render(Graphics2D graphics);

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public float getVelX() {
		return velX;
	}

	public void setVelX(float velX) {
		this.velX = velX;
	}

	public float getVelY() {
		return velY;
	}

	public void setVelY(float velY) {
		this.velY = velY;
	}

	public ID getId() {
		return id;
	}

	public void setId(ID id) {
		this.id = id;
	}

}
