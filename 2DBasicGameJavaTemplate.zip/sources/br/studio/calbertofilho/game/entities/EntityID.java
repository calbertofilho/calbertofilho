package br.studio.calbertofilho.game.entities;

public enum EntityID {

	Player(),
	NPC(),
	Bullet();

}
