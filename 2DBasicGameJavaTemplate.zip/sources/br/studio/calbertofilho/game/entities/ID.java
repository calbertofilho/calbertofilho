package br.studio.calbertofilho.game.entities;

public enum ID {

	Player(),
	NPC(),
	Bullet();

}
