package br.studio.calbertofilho.game.controllers.managers;

import java.awt.Graphics2D;
import java.util.Stack;

import br.studio.calbertofilho.game.controllers.handlers.Keyboard;
import br.studio.calbertofilho.game.controllers.handlers.Mouse;
import br.studio.calbertofilho.game.states.Common;
import br.studio.calbertofilho.game.states.Menu;

public class GameStates {

	private Stack<Common> states;

	public GameStates() {
		states = new Stack<Common>();
		states.push(new Menu(this));
	}

	public void changeState(Common newState) {
		states.push(newState);
	}

	public void input(Mouse mouse, Keyboard keyboard) {
		states.peek().input(mouse, keyboard);
	}

	public void update() {
		states.peek().update();
	}

	public void render(Graphics2D graphics) {
		states.peek().render(graphics);
	}

}
