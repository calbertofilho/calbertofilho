package br.studio.calbertofilho.game.controllers.managers.states;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics2D;
import java.io.File;
import java.io.IOException;

import br.studio.calbertofilho.game.controllers.Camera;
import br.studio.calbertofilho.game.controllers.containers.DrawableFramePanel;
import br.studio.calbertofilho.game.controllers.handlers.Keyboard;
import br.studio.calbertofilho.game.controllers.handlers.Mouse;
import br.studio.calbertofilho.game.controllers.managers.GameStates;
import br.studio.calbertofilho.game.maps.LoadMap;

public class PlayScreen extends CommonScreen {

	private Font textsFont;
	private LoadMap map;
	private Camera camera;

	public PlayScreen(GameStates manager) {
		super(manager);
	}

	@Override
	public void init() {
		try {
			textsFont = Font.createFont(Font.TRUETYPE_FONT, new File("resources/assets/fonts/Aero.ttf"));
		} catch (FontFormatException | IOException e) {
			e.printStackTrace();
		}
		camera = new Camera(0, 0);
		map = new LoadMap("resources/assets/levels/dungeon.xml");
	}

	@Override
	public void input(Mouse mouse, Keyboard keyboard) {
		if (keyboard.upKey.isDown()) {
			camera.setDy(3);
			if (camera.getY() == 0) {
				camera.setDy(0);
			}
		} else if (keyboard.downKey.isDown()) {
			camera.setDy(-3);
			if (camera.getY() <= -(DrawableFramePanel.getGameWidth() + (LoadMap.getMapWidth() / 2))) {
				camera.setDy(0);
			}
		} else if (keyboard.leftKey.isDown()) {
			camera.setDx(3);
			if (camera.getX() == 0) {
				camera.setDx(0);
			}
		} else if (keyboard.rightKey.isDown()) {
			camera.setDx(-3);
			if (camera.getX() <= -(DrawableFramePanel.getGameHeight() + (LoadMap.getMapHeight() / 2))) {
				camera.setDx(0);
			}
		}
		else {
			camera.setDx(0);
			camera.setDy(0);
		}
	}

	@Override
	public void update() {
		camera.update();
	}

	@Override
	public void render(Graphics2D graphics) {
		graphics.setColor(new Color(36, 36, 36));
		graphics.fillRect(0, 0, DrawableFramePanel.getGameWidth(), DrawableFramePanel.getGameHeight());
	// begin camera
		graphics.translate(camera.getX(), camera.getY());
		// render map
			map.render(graphics);
	// end camera
		graphics.translate(-camera.getX(), -camera.getY());
	// show fps counter
		graphics.setColor(Color.YELLOW);
		graphics.setFont(textsFont.deriveFont(Font.BOLD, 20));
		String text = String.format("%.2f fps", DrawableFramePanel.getGameFPS());
		graphics.drawString(text, (DrawableFramePanel.getGameWidth() - graphics.getFontMetrics().stringWidth(text)) - 2, graphics.getFontMetrics().getHeight());
	}

}
