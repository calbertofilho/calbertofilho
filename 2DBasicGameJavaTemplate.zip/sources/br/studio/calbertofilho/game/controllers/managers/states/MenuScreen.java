package br.studio.calbertofilho.game.controllers.managers.states;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;

import br.studio.calbertofilho.game.controllers.containers.DrawableFramePanel;
import br.studio.calbertofilho.game.controllers.handlers.Keyboard;
import br.studio.calbertofilho.game.controllers.handlers.Mouse;
import br.studio.calbertofilho.game.controllers.managers.GameStates;
import br.studio.calbertofilho.game.controllers.soundsystem.AudioPlayer;

public class MenuScreen extends CommonScreen {

	private Font textsFont;
	private String[] options = { "Iniciar", "Op��es", "Ajuda", "Sair" };
	private int currentSelection = 0;
	private int menuPaddingX = 500, menuPaddingY = 450;
	private AudioPlayer menu_bgm, selection_fx, confirmation_fx;

	public MenuScreen(GameStates manager) {
		super(manager);
	}

	@Override
	protected void init() {
		try {
			textsFont = Font.createFont(Font.TRUETYPE_FONT, new File("resources/assets/fonts/Audiowide-Regular.ttf"));
			menu_bgm = new AudioPlayer("resources/assets/sounds/bgm/game-menu-music.wav");
			menu_bgm.setVolume(1.0f); // 50%
			menu_bgm.playSoundContinuously();
			selection_fx = new AudioPlayer("resources/assets/sounds/fx/game-menu-selection.wav");
			selection_fx.setVolume(2.0f); // 100%
			confirmation_fx = new AudioPlayer("resources/assets/sounds/fx/unlock-option-notification.wav");
			confirmation_fx.setVolume(2.0f); // 100%
		} catch (FontFormatException | IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void input(Mouse mouse, Keyboard keyboard) {
		keyboard.escapeKey.tick();
		keyboard.upKey.tick();
		keyboard.downKey.tick();
		keyboard.enterKey.tick();
		if (keyboard.escapeKey.isClicked()) {
			menu_bgm.stopSound();
			confirmation_fx.playSoundOnce();
			System.exit(0);
		}
		if (keyboard.upKey.isClicked()) {
			selection_fx.playSoundOnce();
			currentSelection--;
			if (currentSelection < 0)
				currentSelection = options.length - 1;
		}
		if (keyboard.downKey.isClicked()) {
			selection_fx.playSoundOnce();
			currentSelection++;
			if (currentSelection >= options.length)
				currentSelection = 0;
		}
		if (keyboard.enterKey.isClicked()) {
			menu_bgm.stopSound();
			confirmation_fx.playSoundOnce();
			if (currentSelection == 0) {		// Play state
				manager.changeState(new PlayScreen(manager));
			} else if (currentSelection == 1) {	// Configuration state
				manager.changeState(new ConfigurationScreen(manager));
			} else if (currentSelection == 2) {	// Tutorial state
				manager.changeState(new TutorialScreen(manager));
			} else if (currentSelection == 3)	// Quit game
				System.exit(0);
		}
		if (mouse.getButton() == MouseEvent.BUTTON1)
			System.out.println("Mouse button 1");
	}

	@Override
	public void update() {}

	@Override
	public void render(Graphics2D graphics) {
		graphics.setColor(new Color(135, 206, 250)); //light sky
		graphics.fillRect(0, 0, DrawableFramePanel.getGameWidth(), DrawableFramePanel.getGameHeight());
	// show menu option
		for (int i = 0; i < options.length; i++) {
			String option = options[i];
			if (i == currentSelection)
				graphics.setColor(Color.GREEN);
			else
				graphics.setColor(Color.WHITE);
			graphics.setFont(textsFont.deriveFont(Font.BOLD, 48));
			graphics.drawString(option, menuPaddingX + ((DrawableFramePanel.getGameWidth() - graphics.getFontMetrics().stringWidth(option)) / 2), menuPaddingY + graphics.getFontMetrics().getHeight() + (i * graphics.getFontMetrics().getHeight()));
		} 
	}

}
