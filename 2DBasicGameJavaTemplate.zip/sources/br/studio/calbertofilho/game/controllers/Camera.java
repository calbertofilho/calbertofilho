package br.studio.calbertofilho.game.controllers;

import java.awt.Graphics2D;

import br.studio.calbertofilho.game.controllers.handlers.Keyboard;
import br.studio.calbertofilho.game.controllers.handlers.Mouse;

public class Camera {

	public Camera() {}

	public void input(Mouse mouse, Keyboard keyboard) {}

	public void update() {}

	public void render(Graphics2D graphics) {}

}
