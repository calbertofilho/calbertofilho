package br.studio.calbertofilho.game.controllers.states;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics2D;
import java.io.File;
import java.io.IOException;

import br.studio.calbertofilho.game.controllers.containers.DrawableFramePanel;
import br.studio.calbertofilho.game.controllers.handlers.Keyboard;
import br.studio.calbertofilho.game.controllers.handlers.Mouse;
import br.studio.calbertofilho.game.controllers.managers.GameStates;

public class PlayScreen extends CommonScreen {

	private Font textsFont;

	public PlayScreen(GameStates manager) {
		super(manager);
	}

	@Override
	public void init() {
		try {
			textsFont = Font.createFont(Font.TRUETYPE_FONT, new File("resources/assets/fonts/Aero.ttf"));
		} catch (FontFormatException | IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void input(Mouse mouse, Keyboard keyboard) {}

	@Override
	public void update() {}

	@Override
	public void render(Graphics2D graphics) {
		graphics.setColor(new Color(135, 206, 250)); //light sky
		graphics.fillRect(0, 0, DrawableFramePanel.getGameWidth(), DrawableFramePanel.getGameHeight());
	// show fps counter
		graphics.setColor(Color.YELLOW);
		graphics.setFont(textsFont.deriveFont(Font.BOLD, 20));
		String text = String.format("%.2f fps", DrawableFramePanel.getGameFPS());
		graphics.drawString(text, (DrawableFramePanel.getGameWidth() - graphics.getFontMetrics().stringWidth(text)) - 2, graphics.getFontMetrics().getHeight());
	}

}
