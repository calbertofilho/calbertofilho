package br.studio.calbertofilho.game.controllers.soundsystem;

import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class AudioPlayer {

	private Clip player;
	private AudioInputStream sound;
	private long streamLength;
	private FloatControl volumeControl;

	public AudioPlayer() {
		player = null;
		sound = null;
		volumeControl = null;
		createPlayer();
	}

	public AudioPlayer(String sound) {
		this();
		loadSound(sound);
	}

	private void createPlayer() {
		try {
			player = AudioSystem.getClip();
		} catch (LineUnavailableException e) {
			e.printStackTrace();
		}
	}

	public void loadSound(String path) {
		try {
			sound = AudioSystem.getAudioInputStream(new File(path));
			player.open(sound);
			streamLength = 0;
			volumeControl = (FloatControl) player.getControl(FloatControl.Type.MASTER_GAIN);
		} catch (IOException | UnsupportedAudioFileException | LineUnavailableException e) {
			e.printStackTrace();
		}
	}

	public void playSound(int loops) {
		if (isReady()) {
			player.loop(loops);
			player.start();
		}
	}

	public void playSoundOnce() {
		playSound(0);
	}

	public void playSoundContinuously() {
		playSound(Clip.LOOP_CONTINUOUSLY);
	}

	public void pauseSound() {
		if (isReady()) {
			streamLength = player.getMicrosecondPosition();
			player.stop();
		}
	}

	public void resumeSound() {
		if (isReady()) {
			if (streamLength != 0) {
				player.setMicrosecondPosition(streamLength);
			}
			player.start();
		}
	}

	public void stopSound() {
		if (isReady()) {
			player.stop();
			streamLength = 0;
			player.setMicrosecondPosition(streamLength);
		}
	}

	public void setVolume(double volume) {
		volumeControl.setValue((float) Math.min(volumeControl.getMaximum(), Math.max(volumeControl.getMinimum(), volume)));
	}

	public boolean isPlaying() {
		return player.isRunning();
	}

	public boolean isReady() {
		return ((player != null) && (sound != null));
	}

}
