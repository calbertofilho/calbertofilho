package br.studio.calbertofilho.game.controllers.soundsystem;

import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.BooleanControl;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

public class AudioPlayer implements LineListener {

	private File file;
	private AudioInputStream sound;
    private AudioFormat format;
    private DataLine.Info info;
    private Clip player;
    private FloatControl volumeControl;
    private BooleanControl muteControl;
    private boolean playing, ready;
	private long streamLength;

	public AudioPlayer(String soundPath) {
		try {
			playing = ready = false;
			file = new File(soundPath);
			sound = AudioSystem.getAudioInputStream(file);
			format = sound.getFormat();
			info = new DataLine.Info(Clip.class, format);
			player = (Clip) AudioSystem.getLine(info);
			player.addLineListener(this);
            player.open(sound);
            volumeControl = (FloatControl) player.getControl(FloatControl.Type.MASTER_GAIN);
            muteControl = (BooleanControl) player.getControl(BooleanControl.Type.MUTE);
		} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void update(LineEvent event) {
		if (event.getType() == LineEvent.Type.START)
			playing = true;
		if (event.getType() == LineEvent.Type.STOP)
			playing = false;
		if (event.getType() == LineEvent.Type.OPEN)
			ready = true;
		if (event.getType() == LineEvent.Type.CLOSE)
			ready = false;
	}

	private void playSound(int loops) {
		if (!isPlaying()) {
			if (isReady()) {
				player.loop(loops);
				player.start();
			}
		} else {
			player.setFramePosition(0);
		}

	}

	public void playSoundOnce() {
		playSound(0);
	}

	public void playSoundContinuously() {
		playSound(Clip.LOOP_CONTINUOUSLY);
	}

	public void setPause(boolean pause) {
		if (pause)
			pauseSound();
		else
			resumeSound();
	}

	private void pauseSound() {
		if (isPlaying())
			streamLength = player.getMicrosecondPosition();
		stopSound();
	}

	private void resumeSound() {
		if (streamLength != 0) {
			player.setMicrosecondPosition(streamLength);
			player.start();
		}
	}

	public void stopSound() {
		if (isPlaying()) {
			player.stop();
			streamLength = 0;
			player.setMicrosecondPosition(streamLength);
		}
	}

	public void setVolume(float volume) {
		// Range 0.0f to 2.0f
		volumeControl.setValue((float) Math.min(volumeControl.getMaximum(), Math.max(volumeControl.getMinimum(), ((Math.log(volume) / Math.log(10.0)) * 20.0))));
		System.out.println(volumeControl.getValue());
	}

	public void setMute(boolean mute) {
		muteControl.setValue(mute);
	}

	public void fadeIn(float deltaTime) {}

	public void fadeOut(float deltaTime) {}

	public boolean isPlaying() {
		return playing;
	}

	public boolean isReady() {
		return ready;
	}

}
