package br.studio.calbertofilho.game.objects.maps;

import java.awt.Graphics2D;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import br.studio.calbertofilho.game.animations.Sprite;
import br.studio.calbertofilho.game.objects.Tiles;
import br.studio.calbertofilho.game.objects.tiles.DecorationTile;
import br.studio.calbertofilho.game.objects.tiles.HoleTile;
import br.studio.calbertofilho.game.objects.tiles.InteractiveTile;
import br.studio.calbertofilho.game.objects.tiles.PathTile;
import br.studio.calbertofilho.game.objects.tiles.SolidTile;

public class LoadMap {

	private ArrayList<Tiles> tiles;
	private String imagePath, layerName;
	private int width, height, tileWidth, tileHeight, tileCount, tileColumns, layers;
	private Sprite sprite;
	private String[] data;
	private DocumentBuilderFactory builderFactory;
	private DocumentBuilder documentBuilder;
	private Document document;
	private NodeList list;
	private Node node;
	private Element element;

	public LoadMap() {
		tiles = new ArrayList<Tiles>();
	}

	public LoadMap(String path) {
		this();
		addTilesToMap(path);
	}

	private void addTilesToMap(String path) {
		try {
			builderFactory = DocumentBuilderFactory.newInstance();
			documentBuilder = builderFactory.newDocumentBuilder();
			document = documentBuilder.parse(new File(getClass().getClassLoader().getResource(path).toURI()));
			document.getDocumentElement().normalize();
			list = document.getElementsByTagName("image");
			node = list.item(0);
			element = (Element) node;
			imagePath = element.getAttribute("source");
			list = document.getElementsByTagName("tileset");
			node = list.item(0);
			element = (Element) node;
			tileWidth = Integer.parseInt(element.getAttribute("tilewidth"));
			tileHeight = Integer.parseInt(element.getAttribute("tileheight"));
			tileCount = Integer.parseInt(element.getAttribute("tilecount"));
			tileColumns = Integer.parseInt(element.getAttribute("columns"));
			sprite = new Sprite("resources/assets/images/sceneries/" + imagePath, tileWidth, tileHeight);
			list = document.getElementsByTagName("layer");
			layers = list.getLength();
			data = new String[layers];
			for (int i = 0; i < data.length; i++) {
				node = list.item(i);
				element = (Element) node;
				layerName = "Layer " + element.getAttribute("name");
				if (i <= 0) {
					width = Integer.parseInt(element.getAttribute("width"));
					height = Integer.parseInt(element.getAttribute("height"));
				}
				data[i] = element.getElementsByTagName("data").item(0).getTextContent();
				System.out.println("------ " + layerName + " ------\n" + data[i]);
				if (layerName == "Path")
					tiles.add(new PathTile(data[i], sprite, width, height, tileWidth, tileHeight, i, tileColumns));
				else if (layerName == "Solid")
					tiles.add(new SolidTile());
				else if (layerName == "Decoration")
					tiles.add(new DecorationTile());
				else if (layerName == "Interactive")
					tiles.add(new InteractiveTile());
				else if (layerName == "Hole")
					tiles.add(new HoleTile());
				else
					new DOMException(DOMException.NOT_FOUND_ERR, layerName);
			}
			System.out.println(tileCount + " tiles were loading on map...");
		} catch (ParserConfigurationException | SAXException | IOException | URISyntaxException | DOMException e) {
			e.printStackTrace();
		}
	}

	public void render(Graphics2D graphics) {
		for (Tiles tile : tiles)
			tile.render(graphics);
	}

}
