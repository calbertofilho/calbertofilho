package br.studio.calbertofilho.game.objects;

import java.awt.Graphics2D;
import java.awt.Rectangle;

import br.studio.calbertofilho.game.animations.Sprite;

@SuppressWarnings("serial")
public abstract class Tiles extends Rectangle {

	public static final int DEFAULT_SIZE = 32;
	protected String data;
	protected Sprite sprite;
	protected int width, height, tileWidth, tileHeight, tileLine, tileColumns;

	public Tiles(String data, Sprite sprite, int width, int height, int tileWidth, int tileHeight, int tileLine, int tileColumns) {
		super(0, 0, tileWidth, tileHeight);
		this.data = data;
		this.sprite = sprite;
		this.width = width;
		this.height = height;
		this.tileWidth = tileWidth;
		this.tileHeight = tileHeight;
		this.tileLine = tileLine;
		this.tileColumns = tileColumns;
	}

	public Tiles(int x, int y, int width, int height) {
		setLocation(x, y);
		setSize(width, height);
	}

	public Tiles(int x, int y, int size) {
		this(x, y, size, size);
	}

	public Tiles(int x, int y) {
		this(x, y, DEFAULT_SIZE);
	}

	public Tiles() {}

	public abstract void render(Graphics2D graphics);

}
