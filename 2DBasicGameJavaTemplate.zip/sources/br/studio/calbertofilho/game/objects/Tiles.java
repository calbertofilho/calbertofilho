package br.studio.calbertofilho.game.objects;

import java.awt.Graphics2D;
import java.awt.Rectangle;

@SuppressWarnings("serial")
public abstract class Tiles extends Rectangle {

	public static final int DEFAULT_SIZE = 32;

	public Tiles(int x, int y, int size) {
		setLocation(x, y);
		setSize(size, size);
	}

	public Tiles(int x, int y) {
		this(x, y, DEFAULT_SIZE);
	}

	public Tiles() {}

	public abstract void render(Graphics2D graphics);

}
