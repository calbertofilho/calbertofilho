package br.studio.calbertofilho.game.objects.tiles;

import java.awt.Graphics2D;

import br.studio.calbertofilho.game.objects.Tiles;

@SuppressWarnings("serial")
public class DecorationTile extends Tiles {

	@Override
	public void render(Graphics2D graphics) {}

}
