package br.studio.calbertofilho.game.objects.tiles;

import java.awt.Graphics2D;

import br.studio.calbertofilho.game.animations.Sprite;
import br.studio.calbertofilho.game.objects.Tiles;

@SuppressWarnings("serial")
public class PathTile extends Tiles {

	public PathTile() {
		super();
	}

	public PathTile(int x, int y, int width, int height) {
		super(x, y, width, height);
	}

	public PathTile(int x, int y, int size) {
		super(x, y, size);
	}

	public PathTile(int x, int y) {
		super(x, y);
	}

	public PathTile(String data, Sprite sprite, int width, int height, int tileWidth, int tileHeight, int tileLine, int tileColumns) {
		super(data, sprite, width, height, tileWidth, tileHeight, tileLine, tileColumns);
	}

	@Override
	public void render(Graphics2D graphics) {}

}
